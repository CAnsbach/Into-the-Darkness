﻿/* Made by: Christopher Ansbach
 * Last Modified: 5/2/2019
 * Purpose: This is the Floor scriptable object.
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Text/Floor")]

public class Floor : ScriptableObject
{
    public List<Room> rooms;            //Rooms on the floor
    public int index;                   //Index of the floor
    public Room room;                   //Room the floor starts with
}
