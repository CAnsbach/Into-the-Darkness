﻿/* Made by: Christopher Ansbach
 * Last Modified: 5/2/2019
 * Purpose: This is the Stairs scriptable object.
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Text/Stairs")]

public class Stairs : ScriptableObject
{
    public enum Direction { up, down };             //Directions the stairs can go
    public Direction theDirection;                  //Direction the stairs will go
    [TextArea] public string description;           //Description of the stairs
    public Floor floor;                             //Floor the stairs will lead
    public Room stairRoom;                          //Room the stairs will lead to
}