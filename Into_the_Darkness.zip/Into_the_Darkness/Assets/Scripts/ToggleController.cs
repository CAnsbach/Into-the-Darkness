﻿/* Made by: Christopher Ansbach
 * Last Modified: 5/2/2019
 * Purpose: This script is used to control what the Dark Theme toggle does on activation.
 *          The toggle with switch between light and dark mode.
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ToggleController : MonoBehaviour
{
    public Toggle toggle;                                                               //Toggle to turn dark theme on or off
    public bool themeDark;                                                              //Determine if dark theme is toggled
    public Image background;                                                            //Background image for the game
    public Text displayText, enterText, placeholderText, healthStatus, sanityStatus;    //Text objects to change the color of when changing themes

    private void Start()
    {
        int pref = PlayerPrefs.GetInt("theme", 1);              //Get the player's preferred theme

        //If the preferred theme is 1, toggle dark theme
        if (pref == 1)          
        {
            themeDark = true;
            toggle.isOn = true;
        }

        //Else, toggle light theme
        else
        {
            themeDark = false;
            toggle.isOn = false;
        }

        //Set the theme
        SetTheme();

        //Add a listener for when the toggle is pressed
        toggle.onValueChanged.AddListener(delegate 
        {
            ProcessTrigger();           //Method to call
        });

    }

    /// <summary>
    /// Method to change the theme when the toggle is toggled
    /// 
    /// </summary>
    void ProcessTrigger()
    {
        themeDark = !themeDark;                             //Opposite of the current theme is to be used
        PlayerPrefs.SetInt("theme", themeDark ? 1 : 0);     //If the theme is dark, set the theme preference to 1.  Else, set the preference to 0
        PlayerPrefs.Save();                                 //Save the changes
        SetTheme();                                         //Set the theme
    }

    /// <summary>
    /// Method used to set the theme
    /// 
    /// </summary>
    void SetTheme()
    {
        //If the theme is the dark theme, set background to black and text to green
        if (themeDark)
        {
            background.color = Color.black;
            displayText.color = Color.green;
            enterText.color = Color.green;
            placeholderText.color = Color.green;
            healthStatus.color = Color.green;
            sanityStatus.color = Color.green;
        }

        //Else, set background to white and text to black
        else
        {
            background.color = Color.white;
            displayText.color = Color.black;
            enterText.color = Color.black;
            placeholderText.color = Color.black;
            healthStatus.color = Color.black;
            sanityStatus.color = Color.black;
        }
    }
}
