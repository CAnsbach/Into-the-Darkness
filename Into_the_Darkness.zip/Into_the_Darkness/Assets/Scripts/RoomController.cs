﻿/* Made by: Christopher Ansbach
 * Last Modified: 5/2/2019
 * Purpose: This script is used when the player travels througout the game, more specifically, traversing the rooms.
 *          This allows the player to move between the room scriptable objects.
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoomController : MonoBehaviour
{
    public List<Room> rooms;                //List of rooms on the current flooor
    public Room room;                       //Current room
    public Exit exit;                       //Exit to go through
    public bool fleeing;                    //Determines if the player is currently fleeing
    FloorController fC;                     //FloorController script
    string itemString;                      //String to return that lists the items in the room
    PlayerController pC;                    //PlayerController script
    public Dictionary<string, Room> exits = new Dictionary<string, Room>();             //Dictionary of strings and Rooms used to naviagate the floor (exits)
    public Dictionary<string, Exit> exitStatus = new Dictionary<string, Exit>();        //Dictionary of strings and Exits to determine if the door is locked
    public Dictionary<string, Floor> stairs = new Dictionary<string, Floor>();          //Dictionary of strings and Floors to navigate to another floor (stairs)
    public delegate void RoomChange();      //Delegates used to make the events.
    public delegate void Encounter();
    public event RoomChange OnRoomChange;   //Event to start when a room is changed
    public event Encounter OnEncounter;     //Event to start when an enemy is encountered.
    string exitInfo, stairsInfo;

    private void Start()
    {
        pC = GetComponent<PlayerController>();      //Get the needed scripts
        fC = GetComponent<FloorController>();
    }

    /// <summary>
    /// Method used to Load the room the player last saved in.
    /// 
    /// </summary>
    /// <param name="index"></param>
    public void LoadSavedRoom(int index)
    {
        room = rooms[index];                //Get the room based on the given index
        exits.Clear();                      //Clear out the current exits.

        //The room changed
        if (OnRoomChange != null)
        {
            OnRoomChange();
        }
    }

    /// <summary>
    /// Gets the exits and stairs in the current room and return a string based on the room, exit, and stairs descriptions
    /// 
    /// </summary>
    /// <returns></returns>
    public string UnpackRoom()
    {
        //strings to hold info
        exitInfo = "";
        stairsInfo = "";

        //If the room is the victory room, the player wins
        if (room.roomName == "victory")
        {
            GameManager.instance.Win();
        }

        //For each exit in the room, get the description and add it to the exists dictionary
        foreach (Exit anExit in room.exits)
        {
            exitInfo += " " + anExit.description;
            //If the exit is not in the dictionary, add it and the room it leads to in the appropriate dictionaries.
            if (!exits.ContainsKey(anExit.theDirection.ToString()))
            {
                
                exits.Add(anExit.theDirection.ToString(), anExit.room);

                if (!exitStatus.ContainsKey(anExit.theDirection.ToString()))
                {
                    exitStatus.Add(anExit.theDirection.ToString(), anExit);
                }
            }
        }

        //For each Stairs object in the room, if it is not currently in the dictionary, add the direction and floor to the dictionary.
        foreach (Stairs stairCase in room.stairs)
        {
            if (!stairs.ContainsKey(stairCase.theDirection.ToString()))
            {
                stairsInfo += " " + stairCase.description;                      //Get the description
                stairs.Add(stairCase.theDirection.ToString(), stairCase.floor);
            }
        }

        return room.description + exitInfo + stairsInfo;        //Return the information
    }
    
    /// <summary>
    /// Method used to change rooms in the given direction.
    /// 
    /// </summary>
    /// <param name="direction"></param>
    public void ChangeRooms(string direction)
    {
        //If the exit exists, check if it is locked or the player has a key
        if (exits.ContainsKey(direction))
        {
            //If they do, check if the exit is locked
            if (!exitStatus[direction].isLocked || pC.inventory.Contains("key"))
            {
                //If it is locked, remove the key item and unlock the exit.
                if (exitStatus[direction].isLocked)
                {
                    pC.inventory.Remove("key");
                    exitStatus[direction].isLocked = false;
                    
                    GameManager.instance.UpdateDisplayText("The key breaks on use.");
                }

                room = exits[direction];        //Set the current room

                //If the player is fleeing, update the display text and the player is no longer fleeing.
                if (fleeing)
                {
                    GameManager.instance.UpdateDisplayText("You head " + direction);
                    fleeing = false;
                }

                exits.Clear();                  //Clear the dictionaries
                exitStatus.Clear();

                //The room has changed
                if (OnRoomChange != null)
                {
                    OnRoomChange();
                }
            }

            //Else, the door is locked and the player does not have a key
            else
            {
                GameManager.instance.UpdateDisplayText("The " + direction + " door is locked.");
            }
        }

        //Else, the player walks into a wall
        else
        {
            GameManager.instance.UpdateDisplayText("You walk directly into the " + direction + " wall.");
        }
    }

    /// <summary>
    /// Method used to change the floor if there are stairs in the room
    /// 
    /// </summary>
    /// <param name="direction"></param>
    public void ChangeFloors(string direction)
    {
        //If there are stairs in the given direciton, set the current floor.
        if (stairs.ContainsKey(direction))
        {
            fC.SetCurrentFloor(stairs[direction]);      //Call the method
        }

        //Else, there are no stairs leading in that direction
        else
        {
            GameManager.instance.UpdateDisplayText("There are no stairs leading " + direction);
        }
    }

    /// <summary>
    /// Method that returns true if there wanted item is in the room
    /// 
    /// </summary>
    /// <param name="item"></param>
    /// <returns></returns>
    public bool PickUpItem(string item)
    {
        //If there are items in the room, check to see if the requested one is in it.
        if (room.items.Count != 0)
        {
            foreach (string items in room.items)
            {
                //If it is, return true
                if (item == items)
                {
                    return true;
                }
            }
        }

        //Else, return false
        return false;
    }

    /// <summary>
    /// Method used to return a string of the items in the room.
    /// 
    /// </summary>
    /// <returns></returns>
    public string GetItems()
    {
        itemString = "";                    //String to return

        //If there is nothing in the room, the string is nothing
        if (room.items.Count == 0)
        {
            itemString = "nothing";
        }

        //For loop to go through the items in the room
        for (int i  = 0; i < room.items.Count; i++)
        {
            //Conditions to check if the item is the legendary sword and format the string to return
            if (i == room.items.Count - 1)
            {
                if (room.items[i] == "smitemourne")
                {
                    itemString += room.items[i] + " the legendary sword.";
                }

                else
                {
                    itemString += room.items[i] + ".";
                }
            }

            else
            {
                if (room.items[i] == "smitemourne")
                {
                    itemString += room.items[i] + " the legendary sword, ";
                }

                else
                {
                    itemString += room.items[i] + ", ";
                }
            }
        }

        //Return the item string
        return itemString;
    }

    /// <summary>
    /// Method used to check for encounters
    /// 
    /// </summary>
    public void CheckForEncounter()
    {
        //If the room's hasMonster boolean and the room has a monster, or the room is trapped, there is an encounter
        if (room.hasMonster && room.monsters.Count != 0 || room.isTrapped)
        {
            if (OnEncounter != null)
            {
                OnEncounter();
            }
        }
    }
}
