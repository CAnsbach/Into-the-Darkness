﻿/* Made by: Christopher Ansbach
 * Last Modified: 5/2/2019
 * Purpose: This script is used to add, remove, and move enemies on the floors.
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    int exit;                       //Integer used to choose an exit
    Room roomBeingChacked;          //Room being checked for monsters
    public Enemy[] enemies;         //Array of enemies that can be spawned into the rooms
    Enemy monster;                  //Monster to add
    bool movedMonster;              //Boolean to determine if a monster was moved
    RoomController rC;              //RoomController and FloorController scripts to be used
    FloorController fC;

    private void Start()
    {
        rC = GetComponent<RoomController>();            //Get the needed scripts
        fC = GetComponent<FloorController>();
        RemoveCurrentEnemies();                         //Remove current enemies (used to reset scriptable objects)
        AddMonsters();                                  //Add monsters to the game
    }

    /// <summary>
    /// Method used to move the monster around the floor
    /// 
    /// </summary>
    public void MoveMonster()
    {
        //For each room on the floor, check if there is a monster and that monster has not just been added or moved.
        foreach(Room room in rC.rooms)
        {
            //If there is a monster that was not moved or just added, move the monster
            if (room.monsters.Count != 0 && !room.newMonster)
            {
                monster = room.monsters[0];                     //Get the monster to move
                //If the monster is not the boss of the first level, move it
                if (monster.name != "Demon")
                {
                    room.monsters.Remove(monster);                  //Remove it from previous room
                    exit = Random.Range(0, room.exits.Length);      //Get a random integer based on the number of exits in the room
                    room.hasMonster = false;                        //The room no longer has a monster
                    room.exits[exit].room.monsters.Add(monster);    //Add a monster to the room that the chosen exit lead to
                    room.exits[exit].room.newMonster = true;        //Room has a new monster.
                    movedMonster = true;                            //Monster was moved
                }

                else if (monster.name == "Demon")
                {
                    movedMonster = true;
                }
            }
        }

        //If a monster was not moved
        if (!movedMonster)
        {
            AddMonsters();      //Add monsters
        }

        //For each room on the current floor, the monster is no longer new and if they have a monster update the hasMonster boolean
        foreach(Room room in rC.rooms)
        {
            if (room.newMonster)
            {
                room.newMonster = false;
            }

            if (room.monsters.Count != 0)
            {
                room.hasMonster = true;
            }
        }
        movedMonster = false;       //Reset the boolean
    }

    /// <summary>
    /// Method used to add monsters to the floor
    /// 
    /// </summary>
    public void AddMonsters()
    {
        //For each room on the current floor, if the room has the startWMonster boolean, add a random monster from the array of possible enemies.
        foreach (Room room in rC.rooms)
        {
            if (room.startWMonster)
            {
                room.monsters.Add(enemies[Random.Range(0, enemies.Length - 1)]);
            }

            //If the room is a boss room, add the boss
            else if (room.bossRoom)
            {
                room.monsters.Add(enemies[enemies.Length - 1]);
            }
        }
    }

    /// <summary>
    /// Method used to remove the current enemies to reset the Scriptable objects on restart or initial play.
    /// 
    /// </summary>
    public void RemoveCurrentEnemies()
    {
        //For each floor in the game, check each room and if it has a monster in it, get rid of it.
        foreach(Floor floor in fC.floors)
        {
            for( int i = 0; i < floor.rooms.Count; i++)
            {
                if (floor.rooms[i].monsters.Count != 0)
                {
                    floor.rooms[i].monsters.Clear();
                }

                floor.rooms[i].hasMonster = false;
            }
        }
    }
}
