﻿/* Made by: Christopher Ansbach
 * Last Modified: 5/2/2019
 * Purpose: TThis script is used to set and alter the text objects used in the UI.
 *          The text objects will show the player's current health status and their sanity.
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextController : MonoBehaviour
{
    public Text healthStatus;                   //Health text
    public Text sanityStatus;                   //Sanity text

    /// <summary>
    /// Method used to update the healthStatus text object based on the current state
    /// 
    /// </summary>
    /// <param name="currentState"></param>
	public void UpdateHealthStatusText(string currentState)
    {
        healthStatus.text = "Health Status: " + currentState;
    }

    /// <summary>
    /// Method used to update the sanityStatus text object based on current sanity
    /// 
    /// </summary>
    /// <param name="sanity"></param>
    public void UpdateSanityStatusText(int sanity)
    {
        sanityStatus.text = "Sanity: " + sanity;
    }
}
