﻿/* Made by: Christopher Ansbach
 * Last Modified: 5/2/2019
 * Purpose: This is the Enemy scriptable object.
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Text/Enemy")]

public class Enemy : ScriptableObject
{
    public string enemyName;                //Name of the enemy
    public bool perceptive, legendary;      //Determine if the player can hide or fight the enemy
}
